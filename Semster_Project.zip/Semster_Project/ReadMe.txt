ADJEI KINGSFORD 
UEB3239422
BSc. INFORMATION TECHNOLOGY 
CLASS- I.T-C

Project Description

18. Text-Based Adventure Game
Text-Based Adventure Game is a console application and is designed to be 
interactive and entertaining. It features a variety of locations, objects, and NPCs 
with which the player can interact. The main goal of this project is to practice 
Design Patterns, C++, and basic game development using OOPS. Most of the 
implementation of this game is based on the principles of Object-oriented C++.
Technologies Required: C++ programming language, Command Line Interface
(CLI), String Manipulation, Condition & Loops, File Input/Output, Data Structures,
Object Oriented Programming.