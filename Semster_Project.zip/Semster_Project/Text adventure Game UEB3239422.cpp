#include <iostream>
#include <string>
using namespace std;

int main() {
    string name;
    cout << "Welcome to the Adventure Game!" << endl;
    cout << "What is your name?" << endl;
    getline(cin, name);
    cout << "Hello, " << name << "! Let's begin our adventure." << endl;

    string choice1;
    cout << "You are in a forest. Do you want to go left or right?" << endl;
    getline(cin, choice1);
    if (choice1 == "left") {
        cout << "You have encountered a dragon! Do you want to fight or run away?" << endl;
        string choice2;
        getline(cin, choice2);
        if (choice2 == "fight") {
            cout << "You have defeated the dragon and found treasure!" << endl;
        } else {
            cout << "You have escaped the dragon but missed the treasure." << endl;
        }
    } else {
        cout << "You have found a peaceful meadow and enjoyed a nice picnic." << endl;
    }

    cout << "Thank you for playing the Adventure Game!" << endl;
    return 0;
}

